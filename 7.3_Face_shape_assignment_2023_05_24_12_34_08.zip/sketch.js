function setup() {
  createCanvas(400, 400);
  background(220, 220, 220)
}

function draw() {
  fill(255, 255, 255, 255)
  ellipse(200, 310, 200, 200)
  fill(255, 255, 255);
  ellipse(200, 150, 165, 165);
  fill(0, 0, 0)
  ellipse(165, 140, 50, 50)
  fill(0, 0, 0)
  ellipse(235, 140, 50, 50)
}

